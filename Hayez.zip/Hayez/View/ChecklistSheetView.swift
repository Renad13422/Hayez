//
//  ChecklistSheetView.swift
//  Hayez
//
//

//
// ChecklistSheetView.swift - النسخة المبسطة
// Hayez
//

import SwiftUI

struct ChecklistSheetView: View {
    @EnvironmentObject var appState: AppStateViewModel
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                // ✅ الصورة الأساسية (الخلفية)
                if let character = appState.selectedCharacter {
                    Image(character.workspaceImage)
                        .resizable()
                        .scaledToFill()
                        .frame(width: geo.size.width, height: geo.size.height)
                        .clipped()
                        .ignoresSafeArea()
                        .overlay(lampTapArea)  // إضافة منطقة الضغط على المصباح
                }
            }
            .navigationBarHidden(true)
        }
        .ignoresSafeArea(.all)
    }
    
    // 💡 منطقة الضغط على المصباح
    private var lampTapArea: some View {
        GeometryReader { proxy in
            // 📍 تحديد موقع المصباح في الصورة
            // عدّل هذي القيم حسب موقع المصباح الفعلي في صورتك
            let lampXPosition = proxy.size.width * 0.12   // المسافة من اليسار (12%)
            let lampYPosition = proxy.size.height * 0.38  // المسافة من الأعلى (38%)
            let lampSize = CGSize(
                width: proxy.size.width * 0.10,   // عرض المنطقة القابلة للضغط
                height: proxy.size.height * 0.18  // ارتفاع المنطقة
            )
            
            // مربع شفاف للضغط
            Color.clear
                .frame(width: lampSize.width, height: lampSize.height)
                .position(x: lampXPosition, y: lampYPosition)
                .contentShape(Rectangle())
                .onTapGesture {
                    switchLampMode()  // تبديل وضع الإضاءة
                }
            
            // 🔧 للتجربة: إذا تبي تشوف وين المنطقة القابلة للضغط، غيّر Color.clear لـ Color.red.opacity(0.3)
        }
    }
    
    // 🔄 دالة تبديل وضع الإضاءة
    private func switchLampMode() {
        guard let currentChar = appState.selectedCharacter else { return }
        
        // تحديد اسم الصورة الجديدة
        var newImage = currentChar.workspaceImage
        
        // التبديل بين الأوضاع
        if currentChar.workspaceImage == "mainboy" {
            newImage = "lightboy"
        } else if currentChar.workspaceImage == "lightboy" {
            newImage = "mainboy"
        } else if currentChar.workspaceImage == "maingirl" {
            newImage = "lightgirl"
        } else if currentChar.workspaceImage == "lightgirl" {
            newImage = "maingirl"
        }
        
        // ✨ تحديث الشخصية بالصورة الجديدة
        appState.selectedCharacter = Character(
            name: currentChar.name,
            imageName: currentChar.imageName,
            gender: currentChar.gender,
            workspaceImage: newImage
        )
        
        // 🎵 اختياري: إضافة صوت أو تأثير
        // HapticManager.shared.impact(style: .light)
    }
}

#Preview {
    let appState = AppStateViewModel()
    appState.selectedCharacter = Character(
        name: "Girl",
        imageName: "girlCard",
        gender: .girl,
        workspaceImage: "maingirl"
    )
    
    return ChecklistSheetView()
        .environmentObject(appState)
}
