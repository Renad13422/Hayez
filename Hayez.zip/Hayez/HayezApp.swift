//
//  HayezApp.swift
//  Hayez
//
//  Created by RENAD MAJED ALSHAHRANY  on 09/08/1447 AH.
//

import SwiftUI

@main
struct HayezApp: App {
    var body: some Scene {
        WindowGroup {
            AppRootView()
        }
    }
}
